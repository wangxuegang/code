ssm(spring+spring mvc+mybatis+maven)高仿bilibili视频网站项目实例

里面包含论坛， 购物商城  网页  后台管理的java项目集成

演示地址：    http://106.75.216.49/bilibili/
(服务器不太稳定，可以尝试刷新，感谢大佬捐赠的服务器费用)

开发环境：Eclipse ，JDK 1.8 ，Tomcat7

(论坛/购物/网页/后台)

直接部署到tomcat 下面就可以执行

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E4%B8%BB%E9%A1%B5.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E4%B8%AA%E4%BA%BA%E5%90%8E%E5%8F%B0.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E4%B8%8B%E5%8D%95.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E4%B8%BB%E9%A1%B5%E4%B8%8B%E6%96%B9.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E5%8F%91%E5%B8%96.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E5%9B%9E%E5%A4%8D.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E6%8A%95%E7%A8%BF.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E6%B3%A8%E5%86%8C%E7%94%A8%E6%88%B7.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E7%9B%AE%E5%BD%95.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E8%AE%A2%E5%8D%95%E5%90%8E%E5%8F%B0.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E8%AE%BA%E5%9D%9B.png)

![image](https://github.com/ArvinZhangX/ssm_bilibili/blob/master/bilibili/%E9%A1%B9%E7%9B%AE/%E8%B4%AD%E7%89%A9.png)



运行步骤：

1.建立数据库，导入sql文件
2.更改数据源db.properties设置
3.启动Tomcat
4.浏览器访问：http://localhost:8080
PS: 
项目流程: 下载数据库备份 →→下载static静态文件放到webapp下面→→视频可下载可不下载(重要:static这个文件一定要放在webapp下面 这样项目才可以访问)

视频的地址放到  webapp/static/videolook 这个目录下面 

(数据库备份 项目截图 源码)



(Static 静态文件  这个文件直接放到webapp下面 直接用)


视频连接地址

精力有限有问题可以联系微信  994397633   （只限赞赏用户，谢谢，其他不回复）

![image](https://github.com/ArvinZhangX/file_tem/blob/master/Alipay.png)
如果您觉得对你有帮助，那么你可以给一些支持 工作qq：994397633
![image](https://github.com/ArvinZhangX/file_tem/blob/master/chat_pay.png)
服务器的费用也是一笔开销
为用户提供更好的搜索环境
一杯咖啡
请扫一扫微信支付（留言希望你带上自己的名字^_^）：
![image](https://github.com/ArvinZhangX/file_tem/blob/master/chat_pay.png)

https://github.com/ArvinZhangX/file_tem/blob/master/chat_pay.png

万分感谢赞赏用户  Mr.Smirks 、 aibili, 陈毅 等人支持
使得服务器可以继续维持！！！跪谢大佬


感谢 *浩赞赏支持50元  刁志昕支持20元 .... 后续所有名单都会补充，赞赏用于服务器租用费用，谢谢大家
*文昌   * 小衡   广浩 ....支持 50元
![image](https://github.com/ArvinZhangX/file_tem/blob/master/shang.jpg)

![image](https://github.com/ArvinZhangX/file_tem/blob/master/shang_chen.png)

![image](https://github.com/ArvinZhangX/file_tem/blob/master/shang0714.jpg)

![image](https://github.com/ArvinZhangX/file_tem/blob/master/shang_diao.jpg)




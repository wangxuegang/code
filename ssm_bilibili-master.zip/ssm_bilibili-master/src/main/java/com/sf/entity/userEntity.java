package com.sf.entity;

public class userEntity {
	private String userID;//用户ID
	private String userMingzi;//用户真实名字
	private String userName;//用户名
	private String passWord;//密码
	private String useryinghangka;//银行卡号
	private String usersex;//性别
	private String userHand;//头像
	private String userAddress;//地址
	private String userPhone;//手机
	private String userQQ;//qq
	private String userEmial;//邮箱
	private String userCollection;//收藏
	private String userState;//状态
	private String userLoginTime;//最后登录时间
	private String userIP;//登录IP地址
	private String userPaypassword;//支付密码
	private String userRMB;//用户余额
	
	
	
	public String getUserRMB() {
		return userRMB;
	}
	public void setUserRMB(String userRMB) {
		this.userRMB = userRMB;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getUserMingzi() {
		return userMingzi;
	}
	public void setUserMingzi(String userMingzi) {
		this.userMingzi = userMingzi;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getUseryinghangka() {
		return useryinghangka;
	}
	public void setUseryinghangka(String useryinghangka) {
		this.useryinghangka = useryinghangka;
	}
	public String getUsersex() {
		return usersex;
	}
	public void setUsersex(String usersex) {
		this.usersex = usersex;
	}
	public String getUserHand() {
		return userHand;
	}
	public void setUserHand(String userHand) {
		this.userHand = userHand;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserQQ() {
		return userQQ;
	}
	public void setUserQQ(String userQQ) {
		this.userQQ = userQQ;
	}
	public String getUserEmial() {
		return userEmial;
	}
	public void setUserEmial(String userEmial) {
		this.userEmial = userEmial;
	}
	public String getUserCollection() {
		return userCollection;
	}
	public void setUserCollection(String userCollection) {
		this.userCollection = userCollection;
	}
	public String getUserState() {
		return userState;
	}
	public void setUserState(String userState) {
		this.userState = userState;
	}
	public String getUserLoginTime() {
		return userLoginTime;
	}
	public void setUserLoginTime(String userLoginTime) {
		this.userLoginTime = userLoginTime;
	}
	public String getUserIP() {
		return userIP;
	}
	public void setUserIP(String userIP) {
		this.userIP = userIP;
	}
	public String getUserPaypassword() {
		return userPaypassword;
	}
	public void setUserPaypassword(String userPaypassword) {
		this.userPaypassword = userPaypassword;
	}
	
	
}

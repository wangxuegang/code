package com.sf.service;

public interface Addservice {
	public boolean login();
}

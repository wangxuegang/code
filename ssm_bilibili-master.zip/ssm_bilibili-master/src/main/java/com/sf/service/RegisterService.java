package com.sf.service;

import com.sf.entity.userEntity;

public interface RegisterService {
	
	public boolean RegisterService(userEntity user);
	
	
}

package com.sf.Test;


import java.io.File;

//import it.sauronsoftware.jave.Encoder;
//import it.sauronsoftware.jave.MultimediaInfo;


public class VideoTime {
	public static void main(String[] args) {
	/*	File source = new File("G:\\Program Fox (x00000000)\\他人妻味 小嶋ひより.mp4");
        Encoder encoder = new Encoder();
        try {
             MultimediaInfo m = encoder.getInfo(source);
             long ls = m.getDuration();
             ls=ls/60000;
             System.out.println("此视频时长为:"+ls+"分钟");
             

             long miao=0;
             long ls2 = m.getDuration()/1000;
             miao += ls2;
             System.out.println(miao);
             
             
        } catch (Exception e) {
            e.printStackTrace();
        }*/
	}

}

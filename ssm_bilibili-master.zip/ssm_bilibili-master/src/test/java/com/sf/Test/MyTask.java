package com.sf.Test;

import java.util.TimerTask;

public class MyTask extends TimerTask{


	@Override
	public void run() {
	        System.out.println("我的查询方法!");  
	  
	}
}
